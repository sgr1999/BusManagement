package com.example.dao;

import com.example.entites.BusDepo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BusDepoRepository extends JpaRepository<BusDepo, Long>{
    
}
