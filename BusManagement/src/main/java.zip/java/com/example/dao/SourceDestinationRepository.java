package com.example.dao;

import com.example.entites.SourceDestination;

import org.springframework.data.jpa.repository.JpaRepository;



public interface SourceDestinationRepository extends JpaRepository<SourceDestination, Long>{
    
   
}
