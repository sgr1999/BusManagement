package com.example.dao;

import com.example.entites.BusDetail;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BusDetailRepository extends JpaRepository<BusDetail,Long>{
    
}
