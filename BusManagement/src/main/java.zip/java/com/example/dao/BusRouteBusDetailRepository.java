package com.example.dao;

import com.example.entites.BusRouteBusDetail;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BusRouteBusDetailRepository extends JpaRepository<BusRouteBusDetail,Long>{
    
}
