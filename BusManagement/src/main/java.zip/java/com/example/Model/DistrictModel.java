package com.example.Model;

import com.example.entites.State;

public class DistrictModel {
    

    private Long districtCode;


    private String districtName;


    private State stateId;

    

    public DistrictModel(Long districtCode) {
        this.districtCode = districtCode;
    }

    


    public DistrictModel(String districtName) {
        this.districtName = districtName;
    }




    public DistrictModel(State stateId) {
        this.stateId = stateId;
    }




    public Long getDistrictCode() {
        return districtCode;
    }


    public void setDistrictCode(Long districtCode) {
        this.districtCode = districtCode;
    }


    public String getDistrictName() {
        return districtName;
    }


    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }


    public State getStateId() {
        return stateId;
    }


    public void setStateId(State stateId) {
        this.stateId = stateId;
    }




    @Override
    public String toString() {
        return "DistrictModel [districtCode=" + districtCode + ", districtName=" + districtName + ", stateId=" + stateId
                + "]";
    }


    
}
