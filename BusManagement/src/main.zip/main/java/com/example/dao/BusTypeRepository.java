package com.example.dao;

import com.example.entites.BusType;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BusTypeRepository extends JpaRepository<BusType,Long>{
    
}
