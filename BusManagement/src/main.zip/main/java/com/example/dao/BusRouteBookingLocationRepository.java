package com.example.dao;

import com.example.entites.BusRouteBookingLocation;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BusRouteBookingLocationRepository extends JpaRepository<BusRouteBookingLocation,Long>{
    
}
