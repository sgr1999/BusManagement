package com.example.dao;

import com.example.entites.BusDepoRoute;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BusDepoRouteRepository extends JpaRepository<BusDepoRoute, Long>{
    
    
}
