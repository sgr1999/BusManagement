package com.example.dao;

import com.example.entites.BusBookingDetail;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BusBookingDetailRepository extends JpaRepository<BusBookingDetail,Long>{
    
}
