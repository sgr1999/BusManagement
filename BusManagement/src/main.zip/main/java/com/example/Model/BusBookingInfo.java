package com.example.Model;

import java.util.List;

public class BusBookingInfo {

    private String passengerName;
    private String passengerAge;
    private Long noOfSeat;
    private String transactionId;

    
 

    


    public String getPassengerName() {
        return passengerName;
    }


    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }


   
    public String getPassengerAge() {
        return passengerAge;
    }


    public void setPassengerAge(String passengerAge) {
        this.passengerAge = passengerAge;
    }


    public Long getNoOfSeat() {
        return noOfSeat;
    }


    public void setNoOfSeat(Long noOfSeat) {
        this.noOfSeat = noOfSeat;
    }


    public String getTransactionId() {
        return transactionId;
    }


    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    

    
}
