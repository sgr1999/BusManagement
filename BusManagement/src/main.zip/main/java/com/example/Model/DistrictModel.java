package com.example.Model;


public class DistrictModel {
    

    private Long districtCode;

    private String districtName;



    




    public DistrictModel(Long districtCode, String districtName) {
        this.districtCode = districtCode;
        this.districtName = districtName;
    }

    public Long getDistrictCode() {
        return districtCode;
    }

    public void setDistrictCode(Long districtCode) {
        this.districtCode = districtCode;
    }

    public String getDistrictName() {
        return districtName;
    }

    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }



   




 


}
